<!--##################### footer ##################-->

<footer>
    <div class="down-footer">
        <div class="up-footer">
            <h4>منبر سبيع الإعلامي لتغطية و تنظيم الاحتفالات التواصل على #الجوال_الرسمي (WhatsApp) </h4>
            <h3>0594447503</h3>
        </div>
<div class="down-">
        <div class="container">
        <div class="row">
           <div class=" col-sm-4">
               <h4>روابط مهمه</h4>
             <ul class="ulone">
                <li><a href="#">الرئيسية</a></li>
                <li><a href="#">الاخبار</a></li>
                <li><a href="#">من نحن</a></li>
                <li><a href="#">تويتر</a></li>
                <li><a href="#">كلمة المنبع</a></li>
                <li><a href="#">انستجرام</a></li>
                <li><a href="#">أهداف المنبع</a></li>
                <li><a href="#">تواصل معنا</a></li>
             </ul>
          </div>
           <div class="col-sm-4">
               <h4>تواصل معنا</h4>
             <ul class="ultwo">
                <li><a href="#">
                <i class="fa fa-map-marker" aria-hidden="true"></i>
                    المملكة العربية السعودية</a></li>
                <li><a href="#">
                      <i class="fa fa-phone" aria-hidden="true"></i>
                    <p>
                      <span>4587869214</span>
                      <span>1445896247</span>
                    </p>
                    </a></li>
             </ul>
           </div>
           <div class="col-sm-4">
               <h4>ارسال رساله</h4>
               <form>
                     <input type="text" placeholder="الاسم">
                     <input type="email" placeholder="الايميل">
                   <textarea placeholder="الرسالة" rows="5"></textarea>
                   <button class="btn">إرسال الان</button>
               </form>
           </div>
        </div>
        <div class="finish">
           <div class="row">
             <div class="col-xs-6">
                جميع الحقوق محفوظة لموقع منبر سبيع الإعلامى 2018
             </div>
             <div class="col-xs-6 leftdir">
                 تصميم وبرمجة:<span><a href="#">براند</a></span>
             </div>
           </div>
        </div>
      </div>
    </div>
  </div>
</footer>


    <script type="text/javascript" src="js/jquery-1.11.1.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.carousel.js"></script>
    <script src="js/lightbox.js"></script>
    <script type="text/javascript" src="js/main.js"></script>

</body>
</html>