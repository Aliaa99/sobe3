  <?php
include 'header.php';
?>
<body>
    <div class="branches-nav">
       <div class="container">
           <div class="divmain">
              <span>تقدم بالتهنئة لسعادة المهندس عيد بن حمود السبيعي </span>
               <a href="#">الرئيسيه/</a>
               <a href="#">الاخبار</a>
           </div>
        </div>
    </div>
    <div class="view">
       <div class="container">
          <div class="row">
              <div class="col-md-6 col-sm-4">
                  <div class="imim">
                     <a class="various" href="images/p.png">
                        <img class="example-image" src="images/p.png">
                      </a>
                  </div>
                  <div class="galary">
                     <div class="owl-carousel owl-theme third">
                       <div class="item">
                              <img src="images/p.png">
                        </div>
                       <div class="item">
                              <img src="images/photo1.png">
                        </div>
                       <div class="item">
                              <img src="images/s1.png">
                        
                        </div>
                       <div class="item">
                              <img src="images/logo2.png">
                        </div>

                      </div>
                  </div>
                </div>
              <div class="col-md-6 col-sm-8">
                    <h6>منبر سبيع الإعلامي   @mnbr_subia3<span>12ابريل</span></h6>
                    <div class="new">
                        <h3>تقدم بالتهنئة لسعادة المهندس عيد بن حمود السبيعي</h3>
                        <p>بإسم الجميع نتقدم بالتهنئة لسعادة #المهندس عيد بن حمود #السبيعي
                            مساعد مدير إدارة التشغيل والصيانة بأمانة منطقة الرياض #فوزه بعضوية الهيئة السعودية للمهندسين  في</p>
                  </div>
                  <div class="social">
                     <ul>
                        <li><a href="#" class="whats"><i class="fa fa-whatsapp" aria-hidden="true"></i></a></li>
                        <li><a href="#" class="linkd"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                        <li><a href="#" class="google"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                        <li><a href="#" class="email"><i class="fa fa-envelope-o" aria-hidden="true"></i></a></li>
                        <li><a href="#" class="tweeter"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                        <li><a href="#" class="facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                        <li><a href="#" class="share"><i class="fa fa-share-alt" aria-hidden="true"></i></a></li>
                      </ul>
                  </div>
            </div>
           </div>
        </div>
    </div>

</body>

  <?php
include 'footer.php';
?>

