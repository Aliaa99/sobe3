<!DOCTYPE html>
<html lang="en">
<head>
  <title>web-page</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/bootstrap-rtl.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="css/owl.carousel.min.css">
  <link rel="stylesheet" href="css/owl.theme.default.min.css">
  <link rel="stylesheet" href="css/animate.min.css">
  <link rel="stylesheet" href="css/lightbox.css">
  <link rel="shortcut icon" href="images/logo.png">
  <link rel="stylesheet" href="css/main.css">
  <link rel="stylesheet" href="css/stylesheet.css">

</head>
<body>
                                                                       
<header>
    <nav>
          <div class="logo">
             <img src="images/logo2.png">
          </div>
          <div class="list">
                <ul class="widt">
                  <li><a href="index.php">الرئيسية</a></li>
                  <li><a href="about.php">كلمة المنبر</a></li>
                  <li><a href="goals.php">الاهداف</a></li>
                  <li><a href="#">فريق المنبر</a></li>
                  <li><a href="news.php">الاخبار</a></li>
                  <li><a href="contact.php">تواصل معنا</a></li>
                </ul>
                <ul class="padd">
                  <li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                  <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                  <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                  <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                </ul>
            </div>

    </nav>
</header>
    <div class="side-nav">
        <div class="main">
          <a href="#side-list" class="op"><i class="fa fa-bars" aria-hidden="true"></i></a>
          <a href="#"><img src="images/logo2.png"></a>
        </div>
        <div class="menu2 animated fadeInRight" id="side-list">
          <a href="#side-list" class="clo"><i class="fa fa-times" aria-hidden="true"></i></a>

           <ul>
                  <li><a href="index.php">الرئيسية</a></li>
                  <li><a href="about.php">كلمة المنبر</a></li>
                  <li><a href="goals.php">الاهداف</a></li>
                  <li><a href="#">فريق المنبر</a></li>
                  <li><a href="news.php">الاخبار</a></li>
                  <li><a href="contact.php">تواصل معنا</a></li>
                <div class="lang">
                      <li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                      <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                      <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                      <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                 </div>

           </ul>
        </div>
    </div>


