  <?php
include 'header.php';
?>
<body>
    <div class="branches-nav">
       <div class="container">
           <div class="divmain">
              <span>الاخبار </span>
               <a href="#">الرئيسيه</a>
           </div>
        </div>
    </div>

    <div class="news">
       <div class="container">
          <div class="col-md-4 col-sm-6">
             <a href="view-news.php">
                 <div class="newsview"><img src="images/1.png"></div>
                 <h5>العميد ركن عبدالله حسين بن غنام...</h5>
                 <p>العميد ركن عبدالله حسين بن غنام الجمالين المتحدث الرسمي لـ التمرين العسكري درع الخليج المشترك 1 يعلن إنهاء كافة الاستعدادات لفعاليات ختام التمرين </p>
              </a>
          </div>
          <div class="col-md-4 col-sm-6">
             <a href="view-news.php">
                 <div class="newsview"><iframe width="100%" height="100%" src="https://www.youtube.com/embed/2TDexzkp3kU" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe></div>
                 <h5>العميد ركن عبدالله حسين بن غنام...</h5>
                 <p>العميد ركن عبدالله حسين بن غنام الجمالين المتحدث الرسمي لـ التمرين العسكري درع الخليج المشترك 1 يعلن إنهاء كافة الاستعدادات لفعاليات ختام التمرين </p>
              </a>
          </div>
          <div class="col-md-4 col-sm-6">
             <a href="view-news.php">
                 <div class="newsview"><img src="images/1.png"></div>
                 <h5>العميد ركن عبدالله حسين بن غنام...</h5>
                 <p>العميد ركن عبدالله حسين بن غنام الجمالين المتحدث الرسمي لـ التمرين العسكري درع الخليج المشترك 1 يعلن إنهاء كافة الاستعدادات لفعاليات ختام التمرين </p>
              </a>
          </div>
          <div class="col-md-4 col-sm-6">
             <a href="view-news.php">
                 <div class="newsview"><img src="images/1.png"></div>
                 <h5>العميد ركن عبدالله حسين بن غنام...</h5>
                 <p>العميد ركن عبدالله حسين بن غنام الجمالين المتحدث الرسمي لـ التمرين العسكري درع الخليج المشترك 1 يعلن إنهاء كافة الاستعدادات لفعاليات ختام التمرين </p>
              </a>
          </div>
          <div class="col-md-4 col-sm-6">
             <a href="view-news.php">
                 <div class="newsview"><img src="images/1.png"></div>
                 <h5>العميد ركن عبدالله حسين بن غنام...</h5>
                 <p>العميد ركن عبدالله حسين بن غنام الجمالين المتحدث الرسمي لـ التمرين العسكري درع الخليج المشترك 1 يعلن إنهاء كافة الاستعدادات لفعاليات ختام التمرين </p>
              </a>
          </div>
          <div class="col-md-4 col-sm-6">
             <a href="view-news.php">
                 <div class="newsview"><iframe width="100%" height="100%" src="https://www.youtube.com/embed/2TDexzkp3kU" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe></div>
                 <h5>العميد ركن عبدالله حسين بن غنام...</h5>
                 <p>العميد ركن عبدالله حسين بن غنام الجمالين المتحدث الرسمي لـ التمرين العسكري درع الخليج المشترك 1 يعلن إنهاء كافة الاستعدادات لفعاليات ختام التمرين </p>
              </a>
          </div>


       </div>
    </div>

</body>

  <?php
include 'footer.php';
?>

