$('.one').owlCarousel({
    loop:true,
    margin:10,
    nav:false,
    rtl:true,
    dots:true,
    autoplay:true,
    autoplayTimeout:5000,
    responsive:{
        0:{
            items:1
        }
    }
})
$('.second').owlCarousel({
    loop:true,
    margin:10,
    nav:true,
    rtl:true,
    dots:false,
    navText:["",""],
    navClass:["owl-next","owl-prev"],
    responsive:{
        0:{
            items:1
        },
        600:{
            items:2
        },
        1000:{
            items:3
        }
    }
})

    //fancy box
    $('.various').fancybox({
        padding : 10,
        openEffect  : 'fade'
    });


//menu

$(document).ready(function(){
    $('.main .op').click(function(){
        $('.menu2').css({"width":"70%",})
        $('.main').css({"right":"70%",})
        $(this).toggle();
        $('.main span').toggle();

    });
    $('.menu2 .clo').click(function(){
        $(this).parent().css({"width":"0",})
        $('.main').css({"right":"0",})
        $('.main .op').toggle();
        $('.main span').toggle();
    });
        $('.opop').click(function(){
        $('.men').slideToggle();
    });

});


$('.galary .owl-carousel').owlCarousel({
    loop:true,
    margin:10,
    nav:true,
    rtl:true,
    dots:true,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:3
        },
        1000:{
            items:5
        }
    }
})

  $(document).ready(function(){
    $('.galary img').click(function(){
      $trial=$(this).attr('src');
    $(".imim a img").attr("src", $trial);
    $(".imim a").attr("href", $trial);

    });

  });

